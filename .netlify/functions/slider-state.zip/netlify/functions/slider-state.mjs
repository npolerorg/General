
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/slider-state.mjs
import { getStore } from "@netlify/blobs";
var slider_state_default = async (req) => {
  const store = getStore("slider-state");
  const KEY = "dashboard-sliders";
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json"
  };
  if (req.method === "OPTIONS") {
    return new Response("", { status: 204, headers });
  }
  if (req.method === "GET") {
    try {
      const data = await store.get(KEY);
      if (data) {
        return new Response(data, { status: 200, headers });
      }
      return new Response(JSON.stringify({}), { status: 200, headers });
    } catch (e) {
      return new Response(JSON.stringify({}), { status: 200, headers });
    }
  }
  if (req.method === "POST") {
    try {
      const body = await req.json();
      await store.set(KEY, JSON.stringify(body));
      return new Response(JSON.stringify({ ok: true }), { status: 200, headers });
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message }), { status: 500, headers });
    }
  }
  return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers });
};
var config = {
  path: "/.netlify/functions/slider-state"
};
export {
  config,
  slider_state_default as default
};
